<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.0.47/jquery.fancybox.min.css" />

    <link href="<?php echo e(asset('css/oborudovanie.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(mix('/css/sec_reviews.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_clients.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_oborudovanie.css')); ?>" rel="stylesheet">

    <style>
        .box-opis ul li::before {
            content: "";
            background-image: url(/img/svg/tick.svg);
            width: 18px;
            height: 18px;
            margin-right: 15px;
            padding: 9px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_footer'); ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.0.47/jquery.fancybox.min.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('modals.buy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="page-oborudovanie">
        <div class="container">

            
            <div class="w-100 text-left pt-5 pb-2">
                <h1 class="text-dark"><?php echo e($equipments->type); ?> <?php echo e($equipments->model); ?></h1>
            </div>

            <div class="row h-auto pb-5">
                <div class="card box-menu bg-light">
                    <div class="card-header font-weight-bold p-3">
                        Другое наше оборудование
                    </div>
                    <div class="card-body p-3">
                        
                        <?php $__currentLoopData = DB::table('pages')->where('id_category','=',4)->where('url','<>','oborudovanie')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="pb-2"><a href="/<?php echo e($item->url); ?>#oborudovanie"><?php echo e($item->h1); ?></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="card box-info">
                    <div class="row h-auto">
                        <div class="card box-image">
                            <a data-fancybox href="/img/oborudovanie/<?php echo e($equipments->img); ?>">
                                <img src="/img/oborudovanie/<?php echo e($equipments->img); ?>" alt="" class="img-thumbnail">
                            </a>
                        </div>
                        <div class="card w-50 box-link">
                            <a class="locality modal-show btn btn_bg-red btn_animate text-uppercase"
                               data-theme="<?php echo e($equipments->type); ?> <?php echo e($equipments->model); ?>"
                               data-toggle="modal"
                               data-target="#modal_buy">
                                Купить <?php echo e($equipments->type); ?> <?php echo e($equipments->model); ?>

                            </a>
                        </div>
                        <div class="card box-opis mt-5">
                            
                            <?php if( $equipments->pdf != NULL ): ?>
                                <div class="pdf-icon">
                                    <a target="_blank" href="/files/equipment/<?php echo e($equipments->pdf); ?>">
                                        Инструкция на <?php echo e($equipments->type .' '. $equipments->model); ?></a>
                                </div>
                            <?php endif; ?>

                            
                            <?php echo $equipments->opis; ?>


                            
                            <?php if( $equipments->pdf != NULL ): ?>
                                <div class="pdf-icon">
                                    <a target="_blank" href="/files/equipment/<?php echo e($equipments->pdf); ?>">
                                        Инструкция на <?php echo e($equipments->type .' '. $equipments->model); ?></a>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="card w-100 text-center">
                <div class="card-header text-uppercase font-weight-bold bg-info">
                    <h3 class="text-white m-0">Внимание!</h3>
                </div>
                <div class="card-body bg-light">
                    Для оформления заказа заполните онлайн заявку нажав кнопку <strong>"КУПИТЬ"</strong> или звоните на бесплатную горячую линию:
                    <div class="font-weight-bold"><h3 class="m-0 mt-3"><?php echo e(app('global')['main_phone']); ?></h3></div>
                </div>
            </div>

        </div>

        
        <div class="container">
            <h2>Другие популярные модели</h2>
        </div>
        <?php echo $__env->make('pages.inc.oborud_count',['type' => $equipments->type], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        
        <?php echo $__env->make('pages.inc.sec_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_reviews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>