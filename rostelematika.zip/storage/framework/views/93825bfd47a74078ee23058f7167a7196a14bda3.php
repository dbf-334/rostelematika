


<div class="main-slide" style="background-image: url(/img/main/<?php echo e($img_slide); ?>);">
    <div class="container">

        <div class="card text-box pt-5">
            <div class="card-body">
                <h1 class="text-dark"><?php echo e($page->h1); ?> <?php echo e($domain->postfix3); ?></h1>
            </div>
        </div>

        <div class="card text-box text-box-opis">
            <div class="card-body">
                <ul>
                    <?php $__currentLoopData = $text_slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <i class="svg-icon icon-tick"></i>
                            <?php echo e($item); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <div class="card seven-days">
            бесплатно на 7 дней
        </div>

        <div class="card slide-form">
            <div class="card-body">

                <form id="test_drive_form" class="form__body row h-auto">
                    <?php echo e(csrf_field()); ?>

                    <div class="form__input input input_border-gray input_large">
                        <label class="input__title">Ваше имя</label>
                        <input type="text" class="input__wrap" name="name" placeholder="Иван">
                    </div>
                    <div class="form__input input input_border-gray input_large input_phone">
                        <label class="input__title">телефон</label>
                        <input type="text" class="input__wrap" name="phone" placeholder="Телефон" maxlength="18">
                    </div>

                    
                    <input type="hidden" name="type_order" value="TESTDRIVE">
                    
                    <input type="hidden" name="comment" value="<?php echo e($page->h1); ?>">
                    
                    <input type="hidden" name="url" value="<?php echo e($domain->domain); ?>.ros-telematika.test<?php echo e(request()->getPathInfo()); ?>">

                    <div onclick="sendOrder('test_drive')"
                         class="form__btn btn btn_bg-red btn_animate">Попробовать</div>
                </form>

                <div class="card-footer">
                    <div id="result_send_order_test_drive" class="result_send_order"></div>
                    Нажимая кнопку «Попробовать», вы даете согласие на обработку персональных данных в соответствии с
                    <a class="locality modal-show"
                       data-toggle="modal"
                       data-target="#modal-policy">Политикой конфиденциальности</a>
                </div>

            </div>
        </div>


    </div>
</div>



