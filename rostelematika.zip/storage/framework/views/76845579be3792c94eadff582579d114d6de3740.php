



<div class="oborudovanie container pb-5">
    <div class="row h-auto">

        
        <?php $__currentLoopData = DB::table('equipment')->where('type','=',$type)->orderBy('lider', 'desc')->orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card">
                <?php if($item->lider === 1): ?>
                    <span class="lider"></span>
                <?php endif; ?>

                <a href="/oborudovanie/<?php echo e($item->url); ?>">
                    <div class="card-img">
                        <img src="/img/oborudovanie/<?php echo e($item->img); ?>" alt="">
                    </div>
                    <div class="card-body">
                        <div><?php echo e($item->type); ?></div>
                        <div><?php echo e($item->model); ?></div>
                    </div>
                    <div class="card-footer">
                        <a href="/oborudovanie/<?php echo e($item->url); ?>"
                           class="catalog__btn btn btn_border-gray btn_hover-bg-blue btn_small btn_italic">Подробнее</a>
                        <a class="catalog__btn btn btn_bg-red btn_border-red btn_italic btn_small"
                           data-theme="<?php echo e($item->type); ?> <?php echo e($item->model); ?>"
                           data-toggle="modal"
                           data-target="#modal_compred">
                            Купить
                        </a>
                    </div>
                </a>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <p class="pt-5">Продажа, установка и обслуживание оборудования <strong>"<?php echo e($type); ?>"</strong> осуществляется на всей
        территории <?php echo e($domain->postfix2); ?> и во многих других городах.</p>
</div>
