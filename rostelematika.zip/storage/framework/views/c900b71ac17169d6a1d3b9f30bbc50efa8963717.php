<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    
    <link href="<?php echo e(mix('/css/sec_reviews.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_clients.css')); ?>" rel="stylesheet">

    <style>
        p {text-indent: 20px;}
        #sec_reviews h2 {display: none;}
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-reviews">
        <div class="container">

            
            <div class="w-100 text-left pt-5 pb-2">
                <h1 class="text-dark">Отзыв от <?php echo e($reviews->title); ?></h1>
            </div>

            <div class="w-100 pb-5">
                <div class="text-center pt-2">
                    <img src="/img/reviews/<?php echo e($reviews->img); ?>" alt="" class="w-50 border border-secondary border-2 rounded">
                </div>
                <div class="w-100 pt-5">
                    <div class="w-75 mx-auto"><?php echo $reviews->body; ?></div>
                    <div class="w-75 mx-auto text-right pt-3"><em><?php echo e($reviews->position); ?> / <?php echo e($reviews->fio); ?></em></div>
                </div>
            </div>

        </div>

        
        <?php echo $__env->make('pages.inc.sec_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        
        <div class="w-100 text-center">
            <h2 class="m-0 mt-5">Смотрите другие отзывы</h2>
        </div>
        <?php echo $__env->make('pages.inc.sec_reviews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>