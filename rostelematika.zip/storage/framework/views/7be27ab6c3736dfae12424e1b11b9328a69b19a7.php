<?php echo e(Request::header('Content-Type : text/xml')); ?>

<?php echo '<?xml version="1.0" encoding="UTF-8"?>';?>


<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url($item->url)); ?></loc>
            <lastmod><?php echo e($item->updated_at); ?></lastmod>
            <?php if($item->id == 1): ?>
                <changefreq>weekly</changefreq>
                <priority>1</priority>
            <?php else: ?>
                <changefreq>monthly</changefreq>
                <priority>0.9</priority>
            <?php endif; ?>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url($item->url)); ?></loc>
            <lastmod><?php echo e($item->updated_at); ?></lastmod>
            <changefreq>monthly</changefreq>
            <priority>0.7</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url('/reviews/'.$item->id.'.html')); ?></loc>
            <lastmod><?php echo e($item->updated_at); ?></lastmod>
            <changefreq>yearly</changefreq>
            <priority>0.3</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>