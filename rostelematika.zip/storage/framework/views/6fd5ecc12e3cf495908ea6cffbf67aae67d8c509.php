<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    <link href="<?php echo e(mix('/css/sec_oborudovanie.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_clients.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_reviews.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('modals.compred', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="page-oborudovanie">
        
        <div class="w-100 text-center pt-5 pb-2">
            <h1 class="text-dark">Все GPS Маяки</h1>
        </div>


        <?php echo $__env->make('pages.inc.oborud_all',[ 'type'=>'GPS Маяк'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



        
        <?php echo $__env->make('pages.inc.sec_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_reviews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>