<?php $tbl_page = app('App\Models\Page'); ?>




<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('to_header'); ?>
    <style>
        .page-sitemap .container div ul {
            list-style: none;
        }
        .page-sitemap .container div ul li .secondary li {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            list-style: none;
        }
        .page-sitemap .container div ul li .secondary li i {
            margin-right: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="page-sitemap">
        <div class="container">

            
            <div class="w-100 text-center my-5">
                <h1 class="text-dark"><?php echo e($page->h1); ?></h1>
            </div>

            <div class="w-100 h-auto pb-5">
                <ul>
                    <?php $__currentLoopData = $tbl_page::select('id_category')->where('id_category','<>','0')->distinct()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php $flag=0 ?>

                        <?php $__currentLoopData = $tbl_page::where('id_category', $category->id_category )->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if ($flag==0) {
                                    $flag=1;
                                    echo '<li><h3><a href="'.$item_page->url.'">'.$item_page->h1.'</a></h3><li>';
                                    echo '<ul class="secondary">';
                                } else {
                                    echo '<li><i class="svg-icon icon-tick"></i><a href="'.$item_page->url.'">'.$item_page->h1.'</a></li>';
                                }
                            ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            if ($flag==1) {
                                echo '</ul>';
                            }
                        ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>