<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    <link href="<?php echo e(asset('/css/bye.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(mix('/css/sec_yandex_map.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_smi_news.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_footer'); ?>
    
    <?php echo $__env->make('pages.inc.sec_yandex_map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="page-bye">

        <div class="container pb-4">
            
            <div class="w-100 text-left pb-3 pt-5">
                <h1 class="text-dark" style="font-size: 30px;"><?php echo e($page->h1); ?></h1>
            </div>

            <p>Работать с нами предельно просто:</p>
            <ul>
                <li><i class="svg-icon icon-tick"></i>
                    Вам достаточно оставить заявку, дождаться звонка нашего менеджера, оговорить с ним условия, выбрав соответствующий тариф.</li>
                <li><i class="svg-icon icon-tick"></i>
                    В дальнейшем нужно заключить договор и оплатить.</li>
                <li><i class="svg-icon icon-tick"></i>
                    По окончании этого наши мастера выедут к Вам на место и произведут установку в течение 3 дней.</li>
            </ul>
        </div>


        
        <div class="block-3 pb-5">
            <div class="container">
                <h2 class="text-center text-center pt-5 pb-3 m-0">Наши преимущества</h2>

                <div class="row w-100">

                    <div class="card">
                        <div class="card-body">
                            <div class="mb-4"><i class="svg-icon icon-shield-blue"></i></div>
                            <p>Пожизненная гарантия на оборудование</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="mb-4"><i class="svg-icon icon-24-hours-blue"></i></div>
                            <p>Сервис 48 часов</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="mb-4"><i class="svg-icon icon-save-money-blue"></i></div>
                            <p>Экономите >5% на содержании ТС или мы вернем деньги</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="mb-4"><i class="svg-icon icon-loupe-blue"></i></div>
                            <p>Максимально прозрачный контроль</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>



        
        <?php echo $__env->make('pages.inc.sec_smi_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        
        <div id="map-item" style="width: 100%; height: 350px"></div>


    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>