<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    
    <link href="<?php echo e(mix('/css/sec_services.css')); ?>" rel="stylesheet">

    <style>
        /*** корректировка стилей блока ***/
        #sec_services {
            background-color: transparent;
        }
        #sec_services .container h2 {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-catalog">
        <div class="container">

            
            <div class="w-100 text-left pt-5 pb-2">
                <h1 class="text-dark" style="font-size: 30px;"><?php echo e($page->h1); ?></h1>
            </div>


        </div>

        
        <?php echo $__env->make('pages.inc.sec_services', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>