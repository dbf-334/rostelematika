

<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>

<script>
    $(document).ready(function () {
        ymaps.ready(init);

        function init(){
            var myMap = new ymaps.Map("map-item", {
                center: [ <?php echo e($domain->y_map); ?> ],
                zoom: 16,
                controls: []
            });
            var myPlacemark = new ymaps.Placemark([ <?php echo e($domain->y_map); ?> ], {
                balloonContentBody: '<div class="my_hr1 map__head"><img src="/img/main/mapicon.png"><?php echo e($domain->org); ?></div><p class="map__address">г. <?php echo e($domain->name); ?>, <?php echo e($domain->address); ?></p><div class="map__text"><div><?php echo e(app('global')['main_phone']); ?> (бесплатно по РФ)</div><div><?php echo e($domain->tel1); ?></div><div><?php echo e($domain->tel2); ?></div></div>',
                hintContent: "",
                closeButton: false
            });
            myMap.geoObjects.add(myPlacemark);
        }
    });
</script>