<?php $__env->startSection('content'); ?>
    <?php
        //Делаем новое описание объекта данных для несуществующей страницы /////////////////////////////////////////////
        $page = new \stdClass();
        $page->title = 'Ошибка 404 - Страница не найдена | Ростелематика';
        $page->description = 'Ошибка 404 - Страница не найдена';
    ?>


    <div class="w-100 text-center my-5 py-5">
        <h1 class="display-1 text-muted">404</h1>
        <h2>Страница не найдена</h2>
        <p>К сожалению, такой страницы нет на нашем сайте.<br>
            Возможно, вы ввели неправильный адрес или страница была удалена с сервера.<br>
            Можете перейти на <a href="/" class="text-primary">главную страницу.</a></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>