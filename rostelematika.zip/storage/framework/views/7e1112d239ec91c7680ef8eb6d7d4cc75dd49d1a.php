<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    
    <link href="<?php echo e(mix('/css/sec_clients.css')); ?>" rel="stylesheet">

    <style>
        .card-reviews {max-width: 200px;}
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-reviews">
        <div class="container">

            
            <div class="w-100 text-left pt-5 pb-2">
                <h1 class="text-dark"><?php echo e($page->h1); ?></h1>
            </div>

            <div class="row pb-5 h-auto">
                <?php $__currentLoopData = DB::table('reviews')->where('type','0')->where('visible','=','1')->orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card card-reviews border-0 text-center">
                        <a href="/reviews/<?php echo e($item->id); ?>.html">
                            <div class="card-img pt-2">
                                <img src="/img/reviews/<?php echo e($item->img); ?>" alt="" width="200" height="280"
                                     class="border border-secondary border-2 rounded">
                            </div>
                            <div class="card-body p-0 mt-3">
                                <?php echo e($item->title); ?>

                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

        
        

        
        <?php echo $__env->make('pages.inc.sec_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="my_hr1"></div>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>