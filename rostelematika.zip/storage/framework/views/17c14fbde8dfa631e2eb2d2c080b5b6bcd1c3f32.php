


<div id="sec_advantages">
    <div class="row w-100 ">

        <div class="b1-image"></div>

        <div class="card b1-text">

            <div class="card">
                <div class="card-body">
                    <h2>Спутниковая система Глонасс мониторинга позовляет в режиме реального времени получать
                        полную информацию о работе корпоративного парка ТС.</h2>
                    <p>Она одинаково эффективно применяется на легковых и грузовых автомобилях. автобусах. спецтехнике,
                        водном и воздушном транспорте. При небольшой цене ГЛОНАСС, установка оборудования позволяет
                        оптимизировать расходы компании.</p>
                </div>
            </div>

            <div class="card b1-icon">
                <div class="card-body">
                    <i class="svg-icon icon-certificate"></i>
                    <div>Пожизненная гарантия на оборудование</div>
                </div>
            </div>
            <div class="card b1-icon">
                <div class="card-body">
                    <i class="svg-icon icon-search-user"></i>
                    <div>Максимально прозрачный контроль</div>
                </div>
            </div>
            <div class="card b1-icon">
                <div class="card-body">
                    <i class="svg-icon icon-time-24-7"></i>
                    <div>Сервис 48 часов. Все вопросы решаем за 2 суток</div>
                </div>
            </div>
            <div class="card b1-icon">
                <div class="card-body">
                    <i class="svg-icon icon-finance"></i>
                    <div>Экономите &gt;5%  на содержание ТС или мы вернем деньги</div>
                </div>
            </div>

        </div>
    </div>
</div>
