<?php $__env->startSection('mail_title'); ?>
    <h1 style="margin: 0;">Клиенту требуется техподдержка</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mail_content'); ?>
    <!-- Тело письма -->
    <table style="width: 100%">
        <tr>
            <td style="padding: 30px 0;">
                <p>
                    Клиенту <span style="font-weight: bold; color: #2a7298;"><?php echo e(request()->name); ?></span>
                    номер  <span style="font-weight: bold; color: #2a7298;"><?php echo e(request()->phone); ?></span>,
                    почта  <span style="font-weight: bold; color: #2a7298;"><?php echo e(request()->email); ?></span>
                    нужна помощь по интересующему его вопросу:
                    <span style="font-weight: bold; color: #2a7298;"><?php echo e(request()->comment); ?></span>.
                </p>
                <p>
                    Заявка была сделана со страницы:
                    <a href="<?php echo e(request()->url); ?>" target="_blank"><?php echo e(request()->url); ?></a>
                </p>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('email.layout.base_system', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>