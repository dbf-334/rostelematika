<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    <link href="<?php echo e(asset('css/kursoukazateli.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/sec_main_slide.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/sec_advantages.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_calculator.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_portfolio.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_clients.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_reviews.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_steps.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_commerce.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_oborudovanie.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_footer'); ?>
    <script src="<?php echo e(asset('js/sec_calculator.js')); ?>"></script>

    <script>
        
        $('#sec_clients .img4').attr('src', '/img/pages/kursoukazateli/client_013.png');
        $('#sec_clients .img5').attr('src', '/img/pages/kursoukazateli/client_015.png');
        $('#sec_clients .img6').attr('src', '/img/pages/kursoukazateli/client_019.png');

        
        $('#sec_steps .step5').css('display','none');
        $('#sec_steps .step6').css('display','none');
        $('#sec_steps .step4').addClass('steps__end06');

    </script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('modals.compred', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="page-kursoukazateli">

        
        <?php echo $__env->make('pages.inc.sec_main_slide', [ 'img_slide'=>'kursoukazateli.jpg',
            'text_slide'=>["Отсутствие перекрытий и огрехов при обработке почвы",
                "Сокращение времени выполнения сельхозработ до 50%"] ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        
        <div class="block-1">
            <div class="row h-auto">
                <div class="card laptop" style="margin-top: 25%;"></div>

                <div class="card bodytext">
                    <div class="card-body">
                        <p>Правильная организация работы сельскохозяйственной техники позволяет существенно увеличить ее
                            эффективность и снизить эксплуатационные затраты. Однако в современных компаниях для этого требуется
                            не только наличие исправного транспорта и квалифицированных сотрудников, но и установка дополнительного
                            оборудования. Одним из таких устройств является сельхоз навигатор.</p>
                        <p>Установка на машинах системы параллельного вождения (агронавигатора) позволяет решать целый ряд задач:</p>
                        <ul>
                            <li><i class="svg-icon icon-tick"></i>
                                Обеспечить эффективную работу сельскохозяйственных машин в условиях пониженной видимости (дождь,
                                туман, темное время суток, сильная запыленность воздуха и т.д.);</li>
                            <li><i class="svg-icon icon-tick"></i>
                                Снизить расход горюче-смазочных материалов и удобрений (в некоторых случаях выгода от установки
                                системы может превышать 10%);</li>
                            <li><i class="svg-icon icon-tick"></i>
                                Точно измерять площадь обрабатываемой территории, а также расстояние, пройденное сельскохозяйственной техникой;</li>
                            <li><i class="svg-icon icon-tick"></i>Сократить время на выполнение работ.</li>
                        </ul>
                        <p>Также они дают возможность не использовать маркеры и сигнальщиков при работе техники.</p>
                        <p>Агро навигатор использует систему GPS. Она позволяет получать данные о расположении машины. На основе
                            этих данных строится оптимальная траектория движения транспорта. При минимальном отклонении от заданного
                            маршрута водитель сразу же получит соответствующий сигнал (обновление данных происходит несколько раз в
                            секунду, поэтому информация появляется мгновенно).</p>
                        <p>Курсоуказатель также предоставляет информацию о скорости движения машины, пройденной дистанции и
                            обработанной площади. Погрешность измерений не превышает 20 см, что обеспечивает максимальную экономию средств.</p>
                        <p>По завершению работ владелец может получить подробный отчет о работе системы точного вождения.</p>
                    </div>
                </div>

            </div>
        </div>


        
        <div class="block-1">
            <div class="row h-auto">

                <div class="card bodytext">
                    <div class="card-body">
                        <h2>Из чего состоит курсоуказатель</h2>
                        <p>Стандартный комплект GPS-навигатора для трактора включает в себя следующий набор оборудования:</p>
                        <ul class="list-ok">
                            <li><i class="svg-icon icon-tick"></i>Сам курсоуказатель;</li>
                            <li><i class="svg-icon icon-tick"></i>Зарядное устройство;</li>
                            <li><i class="svg-icon icon-tick"></i>Крепление для навигатора;</li>
                            <li><i class="svg-icon icon-tick"></i>Карта памяти.</li>
                        </ul>
                        <p>Сам агро навигатор имеет дисплей, на который выводятся линии полос и иконка транспортного средства.
                            Выполнять настройку и задействовать различные функции устройства можно с помощью специальных кнопок
                            управления. А о том, что водитель следует или отклоняется от заданного курса, будут говорить загорающиеся светодиоды.</p>
                    </div>
                </div>

                <div class="card laptop" style="background-image: url('/img/pages/kursoukazateli/kursoukazateli-des-r.jpg');"></div>

            </div>
        </div>

        
        <div class="block-5 py-5">
            <div class="container">
                <p>Управлять работой курсоуказателя крайне просто. Все действия понятны на интуитивном уровне, поэтому на
                    обучение уходит не более 30 минут.</p>
                <p>При необходимости, владелец может подключить устройство к компьютеру через USB кабель. Если бесплатно
                    скачать приложение, можно с помощью ПК можно просматривать собранную информацию.</p>
                <p>В настоящее время существует несколько марок навигаторов для тракторов. Эти устройства имеют различный
                    функционал и отличаются по внешнему оформлению. Чаще всего на тракторы устанавливается оборудование
                    марок Trimble и Агроглобал, а также Авег (Avega) и Leica.</p>
                <h2>Какие виды навигации для тракторов существуют</h2>
                <p>В настоящее время существует 2 основных вида навигации сельхозтехники:</p>
                <ul class="list-ok">
                    <li><i class="svg-icon icon-tick"></i>Автопилот;</li>
                    <li><i class="svg-icon icon-tick"></i>Подруливающее устройство;</li>
                    <li><i class="svg-icon icon-tick"></i>Параллельное вождение.</li>
                </ul>
                <p>В первом случае управление машиной происходит в автоматическом режиме. Это позволяет существенно упростить
                    работу человека, но не исключить его вмешательство (тракторист все же нужен для того, чтобы разворачивать машину).</p>
                <p>Системы параллельного вождения не вмешиваются в управление, а только дают водителю подсказки. Они указывают
                    оптимальную траекторию движения и сообщают, когда тракторист отклоняется от курса. Такие устройства включают
                    приемник GPS, контроллер и дисплей, на который выводится вся необходимая информация (курсоуказатель). Их использование
                    позволяет направлять сельскохозяйственную технику строго по параллельным линиям.</p>
                <p>Используя навигатор для трактора, владелец может сократить расходы на обслуживание машины и затраты времени
                    более чем на 10% (в результате цена агронавигатора окупается в короткие сроки). При этом экономятся не только
                    горюче-смазочные материалы, но и удобрения (благодаря более эффективной работе опрыскивателя). А качество обработки
                    поля существенно увеличивается.</p>
                <p>В Ставрополе и Ставропольском крае готовые решения для сельскохозяйственной техники предлагает компания Ростелематика.
                    Наше оборудования подходит для всех типов и моделей машин, в том числе для тракторов МТЗ.</p>
                <p>Чтобы купить курсоуказатель, необходимо оставить заявку на нашем сайте или по телефону, заключить договор и произвести
                    оплату. Далее наши специалисты проведут установку тракторного оборудования под ключ. При необходимости, сотрудники
                    компании готовы провести обучение использованию агронавигатора.</p>
            </div>
        </div>


        
        <div class="container" id="oborudovanie">
            <h2>Оборудование для навигации</h2>
        </div>
        <?php echo $__env->make('pages.inc.oborud_all',['type'=>'Курсоуказатель'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_reviews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <div class="my_hr1"></div>
        <?php echo $__env->make('pages.inc.sec_steps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_commerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>





    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>