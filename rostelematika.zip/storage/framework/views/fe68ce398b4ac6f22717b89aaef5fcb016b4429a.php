<?php $__env->startSection('meta_name_robots'); ?>
    <meta name="robots" content="index, follow"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_header'); ?>
    <link href="<?php echo e(asset('css/legkovoj-transport.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/sec_main_slide.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/sec_advantages.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_calculator.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_portfolio.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_clients.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_reviews.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_steps.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(mix('/css/sec_commerce.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('to_footer'); ?>
    <script src="<?php echo e(asset('js/sec_calculator.js')); ?>"></script>

    <script>
        
        $('#sec_clients .img5').attr('src', '/img/pages/legkovoj-transport/client_017.png');
    </script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="page-legkovoj-transport">

        
        <?php echo $__env->make('pages.inc.sec_main_slide', [ 'img_slide'=>'slider-avto.jpg',
            'text_slide'=>["Контроль местоположения транспорта в режиме реального времени",
                "Контроль расхода топлива"] ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        
        <div class="block-5 py-3 mt-5">
            <div class="container">
                <p>Владельцы транспортных компаний сталкиваются с огромным числом трудностей. Одни из самых распространенных –
                    это слив водителями топлива, а также использование автомобиля для личных целей. Все это ведет к огромному
                    расту затрат на обслуживание машин. И чем менее дисциплинированны сотрудники, тем эти затраты будут выше.</p>
                <p>Существует лишь один способ борьбы с нарушениями. Здесь поможет установка систем спутникового слежения за автомобилем.</p>
                <h2>ГЛОНАСС контроль автомобилей - принцип работы</h2>
                <p>Для работы систем отслеживания требуется целый комплекс оборудования, причем как наземного (вышки сотовой связи,
                    серверы для хранения информации и т.д.), так и космического (искусственные спутники).</p>
            </div>
        </div>


        
        <div class="block-3 pb-5">
            <div class="container">
                <h2 class="text-center text-center pt-5 pb-3 m-0">Преимущества в цифрах</h2>

                <div class="row w-100">

                    <div class="card">
                        <div class="card-body">
                            <div class="b3-head">99,9%</div>
                            <p>Обнаружение сливов</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="b3-head">до 25%</div>
                            <p>Снижение расходов на топливо</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="b3-head">до 19%</div>
                            <p>Снижение расходов на обслуживание</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="b3-head">до 40%</div>
                            <p>Снижение пробега</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        
        <div class="block-5 py-3 my-4">
            <div class="container">
                <p>Основным элементом подобных систем является навигационный трекер. Это устройство ориентируется по положению
                    спутников и позволяет с высокой точностью определять местонахождение автомобиля. Собранные данные записываются
                    на внутреннюю память прибора. Сюда же поступает и информация, собранная с установленных в машине датчиков.</p>
                <p>Система Глонасс на легковой автомобиль для передачи данных использует стандарт GSM (он же используется и на
                    устройствах GPS). Это позволяет применят оборудование во всей зоне покрытия операторов сотовой связи (при
                    этом будет использоваться тот оператор, который обеспечивает лучший сигнал в конкретной точке).</p>
            </div>
        </div>


        
        <div class="block-2">
            <div class="row h-auto">
                <div class="card equipment"></div>

                <div class="card bodytext">
                    <div class="card-body">
                        <p>Если же связь по каким-то причинам пропадет, то система отправит собранные данные при первой же возможности.
                            Далее информация будет храниться на специализированных серверах. Владелец автомобиля сможет в любое время
                            сделать запрос с помощью СМС-команды. Однако для более комфортного использования системы рекомендуется
                            установить на компьютер соответствующее программное обеспечение. В этом случае владелец будет не только
                            получать информацию о расходе топлива и других параметрах ТС, но и сможет увидеть маршруты передвижения
                            автомобиля, а также его положение в реальном времени.</p>
                    </div>
                </div>
            </div>
        </div>


        
        <div class="block-4 py-5">
            <div class="container">
                <div class="row h-auto">
                    <div class="card bodytext">
                        <h3>Из чего состоит система Глонасс для легкового автомобиля</h3>
                        <p>Система мониторинга автомобиля состоят из следующих элементов:</p>
                    </div>

                    <div class="card block-box">
                        <div class="row h-auto">
                            <div class="card element">
                                <div class="card-img">
                                    <img src="/img/pages/legkovoj-transport/solution_1.png" alt="">
                                </div>
                                <div class="card-body">
                                    Самого трекера, с помощью которого определяется время и положение машины
                                </div>
                            </div>

                            <div class="card element">
                                <div class="card-img">
                                    <img src="/img/pages/legkovoj-transport/solution_2.png" alt="">
                                </div>
                                <div class="card-body">
                                    Датчика уровня топлива, который позволяет отслеживать расход бензина
                                </div>
                            </div>

                            <div class="card element">
                                <div class="card-img">
                                    <img src="/img/pages/legkovoj-transport/solution_3.png" alt="">
                                </div>
                                <div class="card-body">
                                    Дополнительных датчиков (зажигания, наличия в салоне пассажиров и т.д.)
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>


        
        <div class="block-5 pb-3">
            <div class="container">
                <p>По желанию клиента, в автомобиль также могут быть установлены камеры. Изображение с них также в режиме
                    реального времени будет поступать владельцу авто.</p>
                <h2>Преимущества отслеживания автомобиля по Glonass</h2>
                <p>Главная цель установки системы слежения – это сокращение затрат на обслуживание автомобиля. Такое оборудование
                    позволяет определять время заправок и сливов топлива, а также маршруты передвижения транспортного средства.
                    Эта информация позволяет владельцу машины пресечь хищение бензина, а также избежать нецелевого использования
                    авто. В результате существенно снизятся затраты на обслуживание и ремонт ТС.</p>
                <p>Обычно экономия составляет не менее 5%. Однако в отдельных случаях эта цифра может достигать 50% и более.
                    Если узнать, сколько стоит Глонасс на автомобиль, становится понятно, что установка окупается уже после
                    нескольких месяцев эксплуатации.</p>
                <p>Кроме того, использование системы Глонасс позволяет существенно повысить уровень культуры вождения. Ведь
                    если транспорт принадлежит компании, водители часто нарушает ПДД и эксплуатирует т. с. небрежно, тем самым
                    сокращаю срок службы и увеличивая затраты на техническое обслуживание автомобиля.</p>
                <p>Оборудование слежение может помочь и самому владельцу транспортного средства. Например, в случае угона автомобиля,
                    его легко можно будет вычислить по установленному маячку.</p>
                <p>Для установки системы слежения на легковой автомобиль в Ставрополе Вы можете обратиться в компанию Ростелематика.
                    Мы готовы установить спутниковое оборудование на любые виды транспортных средств. При этом сотрудники компании
                    сами выедут на объект в любой точке Ставропольского края.</p>
                <p>Уже более 3000 клиентов успели оценить качество систем от компании Ростелматика. На все оборудование мы предоставляем
                    пожизненную гарантию, а также осуществляем техподдержку. Просто оставьте заявку на сайте, и наши специалисты сами
                    свяжутся с Вами для обсуждения деталей проекта и цены Глонасс на автомобиль.</p>
            </div>
        </div>



        
        <?php echo $__env->make('pages.inc.sec_advantages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_calculator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_reviews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <div class="my_hr1"></div>
        <?php echo $__env->make('pages.inc.sec_steps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <?php echo $__env->make('pages.inc.sec_commerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>