


<div id="sec_portfolio" class="container my-5">
    <div class="w-100 text-center">
        <h2>Примеры внедрения и отзывы наших клиентов</h2>
    </div>

    <div id="carouselExampleControls" class="carousel slide" data-interval="false"> 
        <div class="carousel-inner">

            <?php $portfolio_active=1; ?>
            <?php $__currentLoopData = DB::table('reviews')->where('type','1')->where('visible','=','1')->orderBy('id', 'desc')->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item
                    <?php
                        if ($portfolio_active==1) { //делаем активной первую запись
                            $portfolio_active=0;
                            echo 'active';
                            }
                ?>">
                    <div class="card portfolio-box">
                        <div class="row">
                            <div class="card portfolio__data">
                                <div class="card-body">
                                    <div class="portfolio__logo"><img src="/img/section/portfolio/<?php echo e($item->img); ?>"></div>
                                    <div class="portfolio__company"><?php echo e($item->title); ?></div>
                                    <div class="portfolio__text">
                                        <?php echo $item->portfolio; ?>

                                    </div>
                                </div>
                            </div>
                            <div class="card portfolio__review">
                                <div class="card-body">
                                    <div class="review__text">
                                        <p><?php echo e($item->body); ?></p>
                                    </div>
                                    <div class="review__data i-mid">
                                        <div class="review__img"><img src="/img/section/portfolio/<?php echo e($item->avatar); ?>"></div>
                                        <div class="row review__persona">
                                            <div class="review__name"><?php echo e($item->fio); ?></div>
                                            <div class="review__position"><?php echo e($item->position); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <i class="svg-icon icon-arrow-left-gray"></i>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <i class="svg-icon icon-arrow-right-gray"></i>
        </a>
    </div>

</div>
