/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 89);
/******/ })
/************************************************************************/
/******/ ({

/***/ 89:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(90);


/***/ }),

/***/ 90:
/***/ (function(module, exports) {

//--------------------------------------------------------------------------
// Анимация круга / Стили / Разматка на странице
//--------------------------------------------------------------------------
/*
    <div class="circle-container">
        <div class="circlestat" data-dimension="100" data-text="70" data-width="10" data-fontsize="28"
             data-percent="70" data-fgcolor="#01aef2" data-bgcolor="#eee" data-fill="#ddd"></div>
    </div>

.circliful {
    position: relative;
}
.circle-text {
    width: 100%;
    position: absolute;
    text-align: center;
    display: inline-block;
}
*/

//*** скрипт круговой анимации для блоков ***//
(function (a) {
    a.fn.circliful = function (b, d) {
        var c = a.extend({ fgcolor: "#556b2f", bgcolor: "#eee", fill: false, width: 15, dimension: 200, fontsize: 15, percent: 50,
            animationstep: 1, iconsize: "20px", iconcolor: "#999", border: "default", complete: null }, b);
        return this.each(function () {
            var w = ["fgcolor", "bgcolor", "fill", "width", "dimension", "fontsize", "animationstep", "endPercent", "icon", "iconcolor", "iconsize", "border"];
            var f = {};
            var F = "";
            var n = 0;
            var t = a(this);
            var A = false;
            var v, G;
            t.addClass("circliful");
            e(t);

            if (t.data("text") != undefined) {
                v = t.data("text");
                if (t.data("icon") != undefined) {
                    F = a("<i></i>").addClass("fa " + a(this).data("icon")).css({ color: f.iconcolor, "font-size": f.iconsize });
                }
                if (t.data("type") != undefined) {
                    j = a(this).data("type");
                    if (j == "half") {
                        s(t, "circle-text-half", f.dimension / 1.45);
                    } else {
                        s(t, "circle-text", f.dimension);
                    }
                } else {
                    s(t, "circle-text", f.dimension);
                }
            }

            if (a(this).data("total") != undefined && a(this).data("part") != undefined) {
                var I = a(this).data("total") / 100;
                percent = (a(this).data("part") / I / 100).toFixed(3);
                n = (a(this).data("part") / I).toFixed(3);
            } else {
                if (a(this).data("percent") != undefined) {
                    percent = a(this).data("percent") / 100;
                    n = a(this).data("percent");
                } else {
                    percent = c.percent / 100;
                }
            }

            /*if(a(this).data("info")!=undefined){
                G=a(this).data("info");
                if(a(this).data("type")!=undefined){
                    j=a(this).data("type");
                    if(j=="half"){
                        D(t,0.9)
                    }else{
                        D(t,1.25)
                    }
                }else{
                    D(t,1.25)
                }
            }*/

            a(this).width(f.dimension + "px");
            var i = a("<canvas></canvas>").attr({ width: f.dimension, height: f.dimension }).appendTo(a(this)).get(0);
            var g = i.getContext("2d");
            var r = i.width / 2;
            var q = i.height / 2;
            var C = f.percent * 360;
            var H = C * (Math.PI / 180);
            var l = i.width / 2.5;
            var B = 2.3 * Math.PI;
            var z = 0;
            var E = false;
            var o = f.animationstep === 0 ? n : 0;
            var p = Math.max(f.animationstep, 0);
            var u = Math.PI * 2;
            var h = Math.PI / 2;
            var j = "";
            var k = true;

            /*if(a(this).data("type")!=undefined){
                j=a(this).data("type");
                if(j=="half"){
                    B=2*Math.PI;
                    z=3.13;
                    u=Math.PI*1;
                    h=Math.PI/0.996
                }
            }*/

            function s(J, x, y) {
                a("<span></span>").appendTo(J).addClass(x).text(v).prepend(F).css({ "line-height": y + "px", "font-size": f.fontsize + "px" });
            }
            /*function D(y,x){
                a("<span></span>").appendTo(y).addClass("circle-info-half").css("line-height",(f.dimension*x)+"px")
            }*/

            function e(x) {
                a.each(w, function (y, J) {
                    if (x.data(J) != undefined) {
                        f[J] = x.data(J);
                    } else {
                        f[J] = a(c).attr(J);
                    }
                    if (J == "fill" && x.data("fill") != undefined) {
                        A = true;
                    }
                });
            }

            function m(x) {
                g.clearRect(0, 0, i.width, i.height);
                g.beginPath();
                g.arc(r, q, l, z, B, false);
                g.lineWidth = f.width + 1;
                g.strokeStyle = f.bgcolor;
                g.stroke();
                if (A) {
                    g.fillStyle = f.fill;
                    g.fill();
                }
                g.beginPath();
                g.arc(r, q, l, -h, u * x - h, false);
                if (f.border == "outline") {
                    g.lineWidth = f.width + 13;
                } else {
                    if (f.border == "inline") {
                        g.lineWidth = f.width - 13;
                    }
                }
                g.strokeStyle = f.fgcolor;
                g.stroke();
                if (o < n) {
                    o += p;
                    requestAnimationFrame(function () {
                        m(Math.min(o, n) / 100);
                    }, t);
                }
                if (o == n && k && typeof b != "undefined") {
                    if (a.isFunction(b.complete)) {
                        b.complete();k = false;
                    }
                }
            }

            m(o / 100);
        });
    };
})(jQuery);

//базовая функция
$(function () {
    $('.circlestat').circliful();
});

/***/ })

/******/ });